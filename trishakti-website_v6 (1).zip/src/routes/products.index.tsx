import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeading } from "@/components/site-chrome";
import { ProductCard } from "@/components/product-card";
import { products } from "@/lib/site";
import { useLang } from "@/lib/i18n";

export const Route = createFileRoute("/products/")({
  head: () => ({
    meta: [
      { title: "Products — Chiura & Bhuja | Trishakti Khadhya Udhyog" },
      { name: "description", content: "Makhhan Bhuja (3–13 kg) and Kurum Kurum Chiura (400 g–20 kg) from Trishakti Khadhya Udhyog, Nepal." },
      { property: "og:title", content: "Our Products — TSKU" },
      { property: "og:description", content: "Bhuja and chiura in retail and wholesale pack sizes." },
    ],
  }),
  component: Products,
});

const filters = ["All", "Bhuja / Muri", "Chiura"] as const;

function Products() {
  const { t } = useLang();
  const [f, setF] = useState<(typeof filters)[number]>("All");
  const list = f === "All" ? products : products.filter((p) => p.category === f);
  return (
    <>
      <PageHeading eyebrow={t("productsEyebrow")} title={t("productsTitle")} intro={t("productsIntro")} />
      <section className="mx-auto max-w-6xl px-6 py-14">
        <div className="flex flex-wrap gap-2">
          {filters.map((x) => (
            <button
              key={x}
              onClick={() => setF(x)}
              className={`rounded-full border px-5 py-2 text-sm font-medium transition ${f === x ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card hover:bg-secondary"}`}
            >
              {x === "All" ? t("all") : t(x)}
            </button>
          ))}
        </div>
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((p) => (
            <ProductCard key={p.slug} p={p} />
          ))}
        </div>
      </section>
    </>
  );
}
