import { createFileRoute } from "@tanstack/react-router";
import hero from "@/assets/hero.jpg";
import { PageHeading } from "@/components/site-chrome";
import { company } from "@/lib/site";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Us — Trishakti Khadhya Udhyog (TSKU)" },
      { name: "description", content: "Learn about Trishakti Khadhya Udhyog, a chiura and bhuja producer in Saptari, Nepal serving business buyers." },
      { property: "og:title", content: "About Trishakti Khadhya Udhyog" },
      { property: "og:description", content: "A trusted chiura and bhuja producer from Saptari, Nepal." },
    ],
  }),
  component: About,
});

const values = [
  { k: "Quality", v: "Clean, carefully processed grains in every batch." },
  { k: "Trust", v: "Honest weights, fair dealings and long-term relationships." },
  { k: "Service", v: "Flexible pack sizes and dependable delivery for our partners." },
];

function About() {
  return (
    <>
      <PageHeading
        eyebrow="About TSKU"
        title="Rooted in Saptari, serving all of Nepal."
        intro={`${company.name} (${company.nameNe}) supplies chiura and bhuja to wholesalers, retailers, distributors and business buyers across Nepal.`}
      />
      <section className="mx-auto grid max-w-6xl items-center gap-12 px-6 py-20 md:grid-cols-2">
        <img src={hero} alt="Chiura and bhuja baskets" loading="lazy" width={1600} height={1008} className="rounded-3xl shadow-soft" />
        <div>
          <h2 className="text-3xl font-semibold">Our story</h2>
          <p className="mt-4 text-muted-foreground">
            From our facility in Hanumannagar-Kankalini, we produce our Makhhan and Trishakti brands of
            bhuja and chiura — everyday staples enjoyed in homes across the country.
          </p>
          <p className="mt-4 text-muted-foreground">
            We focus on what we do best: consistent, crisp, high-quality grains packed in sizes that suit
            shops, distributors and bulk buyers alike.
          </p>
        </div>
      </section>
      <section className="mx-auto grid max-w-6xl gap-6 px-6 md:grid-cols-3">
        {values.map((x, i) => (
          <div key={x.k} className="rounded-2xl border border-border bg-card p-7">
            <span className="font-display text-4xl text-accent">0{i + 1}</span>
            <h3 className="mt-3 text-xl font-semibold">{x.k}</h3>
            <p className="mt-2 text-muted-foreground">{x.v}</p>
          </div>
        ))}
      </section>
    </>
  );
}
