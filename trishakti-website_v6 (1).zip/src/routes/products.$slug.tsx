import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, Mail, MapPin, MessageCircle, Phone } from "lucide-react";
import { ProductImage } from "@/components/product-image";
import { categoryImage, company, findProduct, productInfo, products, whatsappLink } from "@/lib/site";
import { useLang } from "@/lib/i18n";

export const Route = createFileRoute("/products/$slug")({
  loader: ({ params }) => {
    const p = findProduct(params.slug);
    if (!p) throw notFound();
    return { slug: p.slug };
  },
  head: ({ loaderData }) => {
    const p = loaderData ? findProduct(loaderData.slug) : undefined;
    if (!p) return { meta: [{ title: "Product not found | TSKU" }, { name: "robots", content: "noindex" }] };
    const title = `${p.name} ${p.size} — ${p.nameNe} | Trishakti Khadhya Udhyog`;
    const desc = `${p.name} in ${p.size} pack. ${productInfo[p.name]?.desc.en ?? ""} Order on WhatsApp or call.`;
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:type", content: "product" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  notFoundComponent: () => (
    <div className="mx-auto max-w-xl px-6 py-24 text-center">
      <h1 className="text-3xl font-semibold">Product not found</h1>
      <Link to="/products" className="mt-6 inline-block font-semibold text-primary">← All products</Link>
    </div>
  ),
  component: ProductDetail,
});

function ProductDetail() {
  const { slug } = Route.useLoaderData();
  const p = findProduct(slug)!;
  const info = productInfo[p.name];
  const { lang, t } = useLang();
  const siblings = products.filter((x) => x.name === p.name);
  return (
    <section className="mx-auto max-w-6xl px-6 py-12">
      <Link to="/products" className="inline-flex items-center gap-1 text-sm font-semibold text-primary">
        <ArrowLeft className="h-4 w-4" /> {t("backToProducts")}
      </Link>
      <div className="mt-6 grid gap-10 md:grid-cols-2">
        <div className="aspect-square overflow-hidden rounded-3xl border border-border bg-card shadow-soft">
          <ProductImage src={p.image} fallback={categoryImage[p.category]} alt={`${p.name} ${p.size}`} className="p-6" />
        </div>
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">{t(p.category)}</p>
          <h1 className="mt-2 text-4xl font-semibold md:text-5xl">{lang === "ne" ? p.nameNe : `${p.name} ${p.size}`}</h1>
          <p className="mt-2 text-muted-foreground">{lang === "ne" ? `${p.name} ${p.size}` : p.nameNe}</p>
          {info && <p className="mt-5 text-lg">{info.desc[lang]}</p>}

          <dl className="mt-6 grid gap-4 rounded-2xl border border-border bg-card p-5">
            <div>
              <dt className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">{t("packSize")}</dt>
              <dd className="mt-1 text-lg font-semibold">{lang === "ne" ? p.sizeNe : p.size}</dd>
            </div>
            {info && (
              <div>
                <dt className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">{t("ingredients")}</dt>
                <dd className="mt-1">{info.ingredients[lang]}</dd>
              </div>
            )}
            <div>
              <dt className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">{t("otherSizes")}</dt>
              <dd className="mt-2 flex flex-wrap gap-2">
                {siblings.map((s) => (
                  <Link
                    key={s.slug}
                    to="/products/$slug"
                    params={{ slug: s.slug }}
                    className={`rounded-full border px-4 py-1.5 text-sm font-semibold ${s.slug === p.slug ? "border-primary bg-primary text-primary-foreground" : "border-border hover:bg-secondary"}`}
                  >
                    {lang === "ne" ? s.sizeNe : s.size}
                  </Link>
                ))}
              </dd>
            </div>
          </dl>

          <a
            href={whatsappLink(p, t("waGreeting"))}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary px-7 py-4 font-semibold text-primary-foreground shadow-lift transition hover:brightness-110"
          >
            <MessageCircle className="h-5 w-5" /> {t("orderWhatsApp")}
          </a>

          <div className="mt-6 rounded-2xl bg-secondary/60 p-5 text-sm">
            <h2 className="text-lg font-semibold">{t("howToOrder")}</h2>
            <p className="mt-1 text-muted-foreground">{t("howToOrderText")}</p>
            <ul className="mt-4 space-y-2">
              <li className="flex flex-wrap items-center gap-2">
                <Phone className="h-4 w-4 text-primary" /> {t("call")}:
                {company.phones.map((ph) => (
                  <a key={ph} href={`tel:${ph}`} className="font-semibold hover:text-primary">{ph}</a>
                ))}
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-primary" /> {t("email")}:
                <a href={`mailto:${company.email}`} className="font-semibold hover:text-primary">{company.email}</a>
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-primary" /> {company.address}
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
