import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Mail, MapPin, Phone } from "lucide-react";
import { PageHeading } from "@/components/site-chrome";
import { company } from "@/lib/site";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Trishakti Khadhya Udhyog (TSKU)" },
      { name: "description", content: "Contact Trishakti Khadhya Udhyog in Saptari, Nepal for chiura and bhuja orders. Call 031-440053 or 9842910781." },
      { property: "og:title", content: "Contact Trishakti Khadhya Udhyog" },
      { property: "og:description", content: "Get in touch for bulk chiura and bhuja orders." },
    ],
  }),
  component: Contact,
});

const field = "w-full rounded-xl border border-input bg-card px-4 py-3 outline-none focus:ring-2 focus:ring-ring";

function Contact() {
  const [form, setForm] = useState({ name: "", phone: "", message: "" });
  const submit = (e: FormEvent) => {
    e.preventDefault();
    const body = `Name: ${form.name}\nPhone: ${form.phone}\n\n${form.message}`;
    window.location.href = `mailto:${company.email}?subject=${encodeURIComponent("Product enquiry")}&body=${encodeURIComponent(body)}`;
  };
  return (
    <>
      <PageHeading eyebrow="Contact" title="Let's talk business." intro="Call us or send a message for orders, pricing and distribution." />
      <section className="mx-auto grid max-w-6xl gap-10 px-6 py-16 md:grid-cols-5">
        <div className="space-y-4 md:col-span-2">
          {[
            { icon: Phone, label: "Phone", value: company.phones.map((p) => <a key={p} href={`tel:${p}`} className="block hover:text-primary">{p}</a>) },
            { icon: Mail, label: "Email", value: <a href={`mailto:${company.email}`} className="break-all hover:text-primary">{company.email}</a> },
            { icon: MapPin, label: "Address", value: company.address },
          ].map((c) => (
            <div key={c.label} className="flex gap-4 rounded-2xl border border-border bg-card p-6">
              <c.icon className="mt-1 h-5 w-5 shrink-0 text-primary" />
              <div>
                <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">{c.label}</p>
                <div className="mt-1 font-medium">{c.value}</div>
              </div>
            </div>
          ))}
        </div>
        <form onSubmit={submit} className="space-y-4 rounded-3xl border border-border bg-card p-8 shadow-soft md:col-span-3">
          <h2 className="text-2xl font-semibold">Send an enquiry</h2>
          <input required placeholder="Your name" className={field} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <input required placeholder="Phone number" className={field} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          <textarea required rows={5} placeholder="Which products and quantities?" className={field} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
          <button className="rounded-full bg-primary px-7 py-3 font-semibold text-primary-foreground hover:brightness-110">Send message</button>
        </form>
      </section>
    </>
  );
}
