import b3 from "@/assets/makkhan-bhuja-3kg.webp";
import b5 from "@/assets/makkhan-bhuja-5kg-corrected.webp";
import b10 from "@/assets/makkhan-bhuja-10kg.webp";
import b13 from "@/assets/makkhan-bhuja-13kg.webp";
import k400 from "@/assets/kurum-kurum-400g.webp";
import k800 from "@/assets/kurum-kurum-800g.webp";
import k20 from "@/assets/kurum-kurum-20kg.webp";
import t5 from "@/assets/trishakti-chiura-5kg.webp";
import t20 from "@/assets/trishakti-chiura-20kg.webp";
import chiura from "@/assets/chiura.jpg";
import bhuja from "@/assets/bhuja.jpg";

export const company = {
  name: "Trishakti Khadhya Udhyog",
  nameNe: "त्रिशक्ति खाद्य उद्योग",
  short: "TSKU",
  email: "prakashnayak467@gmail.com",
  phones: ["031-440053", "9842910781", "9819707949"],
  address: "Hanumannagar-Kankalini, Ward 03, Saptari, Nepal",
};

export type Category = "Bhuja / Muri" | "Chiura";

export const categoryImage: Record<Category, string> = {
  "Bhuja / Muri": bhuja,
  Chiura: chiura,
};

export const whatsappNumber = "9779819707949";

export type Product = { slug: string; name: string; nameNe: string; size: string; sizeNe: string; category: Category; image: string };

export const productInfo: Record<string, { ingredients: { en: string; ne: string }; desc: { en: string; ne: string } }> = {
  "Makhhan Bhuja": {
    ingredients: { en: "Selected rice, salt", ne: "छानिएको चामल, नुन" },
    desc: { en: "Light, airy and crunchy puffed rice — perfect for snacks, chatpate and bhuja mixes.", ne: "हल्का, फुलेको र कुरुम्म भुजा — खाजा, चटपटे र भुजा मिक्सका लागि उत्तम।" },
  },
  "Makhhan Kurum Kurum Chiura": {
    ingredients: { en: "Selected paddy rice (100%)", ne: "छानिएको धान चामल (१००%)" },
    desc: { en: "Crisp Kurum Kurum flattened rice, clean and evenly pressed for everyday meals and snacks.", ne: "कुरुम कुरुम चिउरा, सफा र समान रूपमा थिचिएको — दैनिक खाना र खाजाका लागि।" },
  },
  "Trishakti Chiura": {
    ingredients: { en: "Selected paddy rice (100%)", ne: "छानिएको धान चामल (१००%)" },
    desc: { en: "Our signature chiura in value packs for households, hotels and wholesale buyers.", ne: "घर, होटल र थोक खरिदकर्ताका लागि हाम्रो विशेष चिउरा।" },
  },
};

export const products: Product[] = [
  { slug: "makhhan-bhuja-3-kg", name: "Makhhan Bhuja", nameNe: "मख्खन भुजा ३ के.जी.", size: "3 kg", sizeNe: "३ के.जी.", category: "Bhuja / Muri", image: b3 },
  { slug: "makhhan-bhuja-5-kg", name: "Makhhan Bhuja", nameNe: "मख्खन भुजा ५ के.जी.", size: "5 kg", sizeNe: "५ के.जी.", category: "Bhuja / Muri", image: b5 },
  { slug: "makhhan-bhuja-10-kg", name: "Makhhan Bhuja", nameNe: "मख्खन भुजा १० के.जी.", size: "10 kg", sizeNe: "१० के.जी.", category: "Bhuja / Muri", image: b10 },
  { slug: "makhhan-bhuja-13-kg", name: "Makhhan Bhuja", nameNe: "मख्खन भुजा १३ के.जी.", size: "13 kg", sizeNe: "१३ के.जी.", category: "Bhuja / Muri", image: b13 },
  { slug: "makhhan-kurum-kurum-chiura-400-g", name: "Makhhan Kurum Kurum Chiura", nameNe: "मख्खन चिउरा कुरुम कुरुम ४०० ग्राम", size: "400 g", sizeNe: "४०० ग्राम", category: "Chiura", image: k400 },
  { slug: "makhhan-kurum-kurum-chiura-800-g", name: "Makhhan Kurum Kurum Chiura", nameNe: "मख्खन चिउरा कुरुम कुरुम ८०० ग्राम", size: "800 g", sizeNe: "८०० ग्राम", category: "Chiura", image: k800 },
  { slug: "trishakti-chiura-5-kg", name: "Trishakti Chiura", nameNe: "त्रिशक्ति चिउरा ५ के.जी.", size: "5 kg", sizeNe: "५ के.जी.", category: "Chiura", image: t5 },
  { slug: "makhhan-kurum-kurum-chiura-20-kg", name: "Makhhan Kurum Kurum Chiura", nameNe: "मख्खन चिउरा कुरुम कुरुम २० के.जी.", size: "20 kg", sizeNe: "२० के.जी.", category: "Chiura", image: k20 },
  { slug: "trishakti-chiura-20-kg", name: "Trishakti Chiura", nameNe: "त्रिशक्ति चिउरा २० के.जी.", size: "20 kg", sizeNe: "२० के.जी.", category: "Chiura", image: t20 },
];

export const findProduct = (slug: string) => products.find((p) => p.slug === slug);

export function whatsappLink(p: Product, greeting: string) {
  const text = `${greeting}: ${p.name} (${p.nameNe}) — ${p.size}`;
  return `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(text)}`;
}
