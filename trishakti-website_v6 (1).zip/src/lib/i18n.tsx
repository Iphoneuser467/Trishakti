import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "en" | "ne";

const dict = {
  home: { en: "Home", ne: "गृहपृष्ठ" },
  about: { en: "About", ne: "हाम्रो बारेमा" },
  products: { en: "Products", ne: "उत्पादनहरू" },
  contact: { en: "Contact", ne: "सम्पर्क" },
  discover: { en: "Discover", ne: "खोज्नुहोस्" },
  footerTag: {
    en: "Quality chiura and bhuja for wholesalers, retailers and distributors across Nepal.",
    ne: "नेपालभरका थोक, खुद्रा र वितरकहरूका लागि गुणस्तरीय चिउरा र भुजा।",
  },
  rights: { en: "All rights reserved.", ne: "सर्वाधिकार सुरक्षित।" },
  all: { en: "All", ne: "सबै" },
  "Bhuja / Muri": { en: "Bhuja / Muri", ne: "भुजा / मुरी" },
  Chiura: { en: "Chiura", ne: "चिउरा" },
  productsEyebrow: { en: "Our products", ne: "हाम्रा उत्पादनहरू" },
  productsTitle: { en: "Bhuja & Chiura, in every size you need.", ne: "भुजा र चिउरा, तपाईंलाई चाहिने हरेक साइजमा।" },
  productsIntro: { en: "Retail packs for shops and large sacks for wholesale buyers.", ne: "पसलका लागि खुद्रा प्याक र थोक खरिदकर्ताका लागि ठूला बोरा।" },
  orderWhatsApp: { en: "Order on WhatsApp", ne: "WhatsApp मा अर्डर" },
  details: { en: "Details", ne: "विवरण" },
  packSize: { en: "Pack size", ne: "प्याक साइज" },
  otherSizes: { en: "Available pack sizes", ne: "उपलब्ध प्याक साइजहरू" },
  ingredients: { en: "Ingredients", ne: "सामग्री" },
  howToOrder: { en: "How to order", ne: "कसरी अर्डर गर्ने" },
  howToOrderText: {
    en: "Message us on WhatsApp or call any number below. Tell us the product, pack size and quantity — we reply with pricing the same day.",
    ne: "WhatsApp मा सन्देश पठाउनुहोस् वा तलको कुनै पनि नम्बरमा फोन गर्नुहोस्। उत्पादन, प्याक साइज र परिमाण बताउनुहोस् — हामी सोही दिन मूल्य पठाउँछौं।",
  },
  call: { en: "Call", ne: "फोन" },
  email: { en: "Email", ne: "इमेल" },
  address: { en: "Address", ne: "ठेगाना" },
  backToProducts: { en: "All products", ne: "सबै उत्पादनहरू" },
  madeIn: { en: "Made fresh in Saptari, Nepal", ne: "सप्तरी, नेपालमा ताजा उत्पादन" },
  waGreeting: { en: "Hello, I would like to order", ne: "नमस्ते, मलाई अर्डर गर्न मन छ" },
  heroBadge: { en: "Proudly Nepali", ne: "गर्वका साथ नेपाली" },
  heroLine1: { en: "Quality Grains.", ne: "गुणस्तरीय अन्न।" },
  heroLine2: { en: "Built on Trust.", ne: "विश्वासमा आधारित।" },
  heroText: {
    en: "Premium chiura and bhuja for wholesalers, retailers and distributors in every corner of Nepal — made fresh in Saptari.",
    ne: "नेपालका हरेक कुनाका थोक, खुद्रा र वितरकहरूका लागि उत्कृष्ट चिउरा र भुजा — सप्तरीमा ताजा बनाइएको।",
  },
  bulkPricing: { en: "Get bulk pricing", ne: "थोक मूल्य लिनुहोस्" },
  viewProducts: { en: "View products", ne: "उत्पादनहरू हेर्नुहोस्" },
  popularPacks: { en: "Popular packs", ne: "लोकप्रिय प्याकहरू" },
  viewAll: { en: "View all", ne: "सबै हेर्नुहोस्" },
} as const;

export type DictKey = keyof typeof dict;

const Ctx = createContext<{ lang: Lang; setLang: (l: Lang) => void }>({ lang: "en", setLang: () => {} });

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en");
  useEffect(() => {
    const saved = localStorage.getItem("tsku-lang");
    if (saved === "ne" || saved === "en") setLangState(saved);
  }, []);
  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);
  const setLang = (l: Lang) => {
    setLangState(l);
    localStorage.setItem("tsku-lang", l);
  };
  return <Ctx.Provider value={{ lang, setLang }}>{children}</Ctx.Provider>;
}

export function useLang() {
  const { lang, setLang } = useContext(Ctx);
  const t = (k: DictKey) => dict[k][lang];
  return { lang, setLang, t };
}

export function LangSwitcher() {
  const { lang, setLang } = useLang();
  return (
    <div role="group" aria-label="Language" className="flex rounded-full border border-border bg-card p-0.5 text-xs font-semibold">
      {(["en", "ne"] as const).map((l) => (
        <button
          key={l}
          type="button"
          onClick={() => setLang(l)}
          aria-pressed={lang === l}
          className={`rounded-full px-3 py-1.5 transition ${lang === l ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
        >
          {l === "en" ? "EN" : "नेपाली"}
        </button>
      ))}
    </div>
  );
}
