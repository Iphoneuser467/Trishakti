const SLICES = 24;

/** Nepal flag on a pole that waves in the wind (sliced-background technique). */
export function FlyingFlag({ width = 180 }: { width?: number }) {
  const height = Math.round(width * 1.22);
  const sw = width / SLICES;
  return (
    <div className="relative flex items-start" style={{ height: height + 40 }} aria-label="Flag of Nepal" role="img">
      <div className="relative z-10 flex flex-col items-center">
        <span className="h-4 w-4 rounded-full bg-gold shadow-lift" />
        <span className="w-2 rounded-b bg-gradient-to-r from-muted-foreground via-secondary to-muted-foreground" style={{ height: height + 30 }} />
      </div>
      <div className="mt-4 flex drop-shadow-2xl" style={{ height }}>
        {Array.from({ length: SLICES }).map((_, i) => (
          <div
            key={i}
            className="flag-slice"
            style={{
              width: sw,
              height,
              backgroundImage: "url(/nepal-flag.svg)",
              backgroundSize: `${width}px ${height}px`,
              backgroundPosition: `-${i * sw}px 0`,
              animationDelay: `${-i * 0.09}s`,
              animationDuration: "2.2s",
              ["--amp" as string]: `${2 + i * 0.6}px`,
              ["--skew" as string]: `${1 + i * 0.12}deg`,
            }}
          />
        ))}
      </div>
    </div>
  );
}
