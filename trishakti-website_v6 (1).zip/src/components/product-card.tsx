import { Link } from "@tanstack/react-router";
import { MessageCircle } from "lucide-react";
import { ProductImage } from "@/components/product-image";
import { categoryImage, whatsappLink, type Product } from "@/lib/site";
import { useLang } from "@/lib/i18n";

export function ProductCard({ p }: { p: Product }) {
  const { lang, t } = useLang();
  const title = lang === "ne" ? p.nameNe : `${p.name} ${p.size}`;
  const sub = lang === "ne" ? `${p.name} ${p.size}` : p.nameNe;
  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-soft transition-transform hover:-translate-y-1">
      <Link to="/products/$slug" params={{ slug: p.slug }} className="relative block aspect-square overflow-hidden border-b border-border bg-card">
        <ProductImage src={p.image} fallback={categoryImage[p.category]} alt={`${p.name} ${p.size}`} className="p-4 transition-transform duration-500 group-hover:scale-105" />
        <span className="absolute left-3 top-3 rounded-full bg-background/90 px-3 py-1 text-xs font-medium">{t(p.category)}</span>
        <span className="absolute right-3 top-3 rounded-full bg-accent px-3 py-1 text-xs font-bold text-accent-foreground">
          {lang === "ne" ? p.sizeNe : p.size}
        </span>
      </Link>
      <div className="flex flex-1 flex-col p-5">
        <Link to="/products/$slug" params={{ slug: p.slug }}>
          <h3 className="text-lg font-semibold hover:text-primary">{title}</h3>
        </Link>
        <p className="mt-1 text-sm text-muted-foreground">{sub}</p>
        <div className="mt-4 flex gap-2 pt-1">
          <a
            href={whatsappLink(p, t("waGreeting"))}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition hover:brightness-110"
          >
            <MessageCircle className="h-4 w-4" /> {t("orderWhatsApp")}
          </a>
          <Link
            to="/products/$slug"
            params={{ slug: p.slug }}
            className="inline-flex items-center rounded-full border border-border px-4 py-2.5 text-sm font-semibold hover:bg-secondary"
          >
            {t("details")}
          </Link>
        </div>
      </div>
    </article>
  );
}
