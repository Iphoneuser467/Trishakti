import { Link } from "@tanstack/react-router";
import { Mail, MapPin, Phone } from "lucide-react";
import { company } from "@/lib/site";
import { FlyingFlag } from "@/components/flying-flag";
import { LangSwitcher, useLang } from "@/lib/i18n";

const nav = [
  { to: "/", label: "home" },
  { to: "/about", label: "about" },
  { to: "/products", label: "products" },
  { to: "/contact", label: "contact" },
] as const;

export function SiteHeader() {
  const { t } = useLang();
  return (
    <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur">
      <div className="hidden bg-deep text-deep-foreground md:block">
        <div className="mx-auto flex max-w-6xl items-center justify-end gap-6 px-6 py-2 text-xs">
          <a href={`mailto:${company.email}`} className="flex items-center gap-1.5 opacity-90 hover:opacity-100">
            <Mail className="h-3.5 w-3.5" /> {company.email}
          </a>
          <a href={`tel:${company.phones[1]}`} className="flex items-center gap-1.5 opacity-90 hover:opacity-100">
            <Phone className="h-3.5 w-3.5" /> {company.phones.join(" · ")}
          </a>
        </div>
      </div>
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-6 py-4">
        <Link to="/" className="flex items-center gap-3">
          <span className="-mb-4 -mt-1 block"><FlyingFlag width={26} /></span>
          <span className="leading-tight">
            <span className="block font-display text-lg font-semibold">{company.short}</span>
            <span className="block text-xs text-muted-foreground">{company.nameNe}</span>
          </span>
        </Link>
        <nav className="flex flex-wrap items-center gap-1 text-sm font-medium">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              activeOptions={{ exact: n.to !== "/products" }}
              className="rounded-full px-3 py-2 text-muted-foreground transition-colors hover:text-foreground data-[status=active]:bg-secondary data-[status=active]:text-foreground"
            >
              {t(n.label)}
            </Link>
          ))}
          <span className="ml-2"><LangSwitcher /></span>
        </nav>
      </div>
    </header>
  );
}

export function SiteFooter() {
  const { t } = useLang();
  return (
    <footer className="mt-24 bg-deep text-deep-foreground">
      <div className="mx-auto grid max-w-6xl gap-10 px-6 py-14 md:grid-cols-3">
        <div>
          <p className="flex items-center gap-2 font-display text-2xl"><img src="/nepal-flag.svg" alt="Nepal flag" className="h-8 w-6" />{company.short}</p>
          <p className="mt-1 opacity-80">{company.nameNe}</p>
          <p className="mt-4 text-sm opacity-70">
            {t("footerTag")}
          </p>
        </div>
        <div className="text-sm">
          <p className="mb-3 font-semibold uppercase tracking-widest opacity-60">{t("discover")}</p>
          <ul className="space-y-2">
            {nav.map((n) => (
              <li key={n.to}>
                <Link to={n.to} className="opacity-85 hover:opacity-100">{t(n.label)}</Link>
              </li>
            ))}
          </ul>
        </div>
        <div className="space-y-3 text-sm">
          <p className="mb-3 font-semibold uppercase tracking-widest opacity-60">{t("contact")}</p>
          <p className="flex gap-2"><Phone className="h-4 w-4 shrink-0" /> {company.phones.join(", ")}</p>
          <p className="flex gap-2"><Mail className="h-4 w-4 shrink-0" /> {company.email}</p>
          <p className="flex gap-2"><MapPin className="h-4 w-4 shrink-0" /> {company.address}</p>
        </div>
      </div>
      <div className="border-t border-deep-foreground/15 py-5 text-center text-xs opacity-60">
        © {new Date().getFullYear()} {company.name} ({company.short}). {t("rights")}
      </div>
    </footer>
  );
}

export function PageHeading({ eyebrow, title, intro }: { eyebrow: string; title: string; intro?: string }) {
  return (
    <section className="bg-secondary/60">
      <div className="mx-auto max-w-6xl px-6 py-16 md:py-20">
        <p className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">{eyebrow}</p>
        <h1 className="mt-3 max-w-3xl text-4xl font-semibold md:text-5xl">{title}</h1>
        {intro && <p className="mt-4 max-w-2xl text-lg text-muted-foreground">{intro}</p>}
      </div>
    </section>
  );
}
