import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

/** Product photo that falls back to a clean category photo if the pack image can't load. */
export function ProductImage({ src, fallback, alt, className }: { src: string; fallback: string; alt: string; className?: string }) {
  const ref = useRef<HTMLImageElement>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    const probe = new Image();
    probe.onerror = () => setFailed(true);
    probe.src = src;
    const img = ref.current;
    if (img && img.complete && img.naturalWidth === 0) setFailed(true);
  }, [src]);
  return (
    <img
      ref={ref}
      src={failed ? fallback : src}
      alt={alt}
      loading="lazy"
      onError={() => setFailed(true)}
      className={cn(failed ? "h-full w-full object-cover" : cn("h-full w-full object-contain p-2", className))}
    />
  );
}
