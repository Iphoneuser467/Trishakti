import { ProductImage } from "@/components/product-image";
import { categoryImage, products } from "@/lib/site";

export function ProductCard({ p }: { p: (typeof products)[number] }) {
  return (
    <article className="group overflow-hidden rounded-2xl border border-border bg-card shadow-soft transition-transform hover:-translate-y-1">
      <div className="relative aspect-square overflow-hidden border-b border-border bg-card">
        <ProductImage src={p.image} fallback={categoryImage[p.category]} alt={`${p.name} ${p.size}`} className="p-4 transition-transform duration-500 group-hover:scale-105" />
        <span className="absolute left-3 top-3 rounded-full bg-background/90 px-3 py-1 text-xs font-medium">
          {p.category}
        </span>
        <span className="absolute right-3 top-3 rounded-full bg-accent px-3 py-1 text-xs font-bold text-accent-foreground">
          {p.size}
        </span>
      </div>
      <div className="p-5">
        <h3 className="text-lg font-semibold">{p.name} {p.size}</h3>
        <p className="mt-1 text-sm text-muted-foreground">{p.nameNe}</p>
      </div>
    </article>
  );
}
