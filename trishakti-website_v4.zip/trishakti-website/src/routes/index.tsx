import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Award, BadgeCheck, Factory, Handshake, Package, Phone, ShieldCheck, Truck } from "lucide-react";
import hero from "@/assets/hero.jpg";
import chiura from "@/assets/chiura.jpg";
import bhuja from "@/assets/bhuja.jpg";
import { categoryImage, company, products } from "@/lib/site";
import { ProductCard } from "@/components/product-card";
import { ProductImage } from "@/components/product-image";
import { FlyingFlag } from "@/components/flying-flag";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Trishakti Khadhya Udhyog — Nepal's Trusted Chiura & Bhuja Maker" },
      { name: "description", content: "Proudly Nepali. TSKU supplies premium chiura and bhuja to wholesalers, retailers and distributors across Nepal from Saptari." },
      { property: "og:title", content: "Trishakti Khadhya Udhyog — Proudly Nepali Chiura & Bhuja" },
      { property: "og:description", content: "Premium grains, honest weights, reliable bulk supply for businesses across Nepal." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const stats = [
  { n: "9+", l: "Pack sizes" },
  { n: "400g–20kg", l: "Retail to wholesale" },
  { n: "100%", l: "Made in Nepal" },
  { n: "Saptari", l: "Our home facility" },
];

const features = [
  { icon: Award, title: "Consistent quality", text: "Carefully processed grains — crisp, clean and uniform in every pack." },
  { icon: Package, title: "Sizes for every buyer", text: "From 400 g shelf packs to 20 kg wholesale sacks." },
  { icon: Truck, title: "Reliable supply", text: "Dependable bulk dispatch for distributors across Nepal." },
  { icon: Handshake, title: "Fair partner pricing", text: "Transparent rates and margins that help your business grow." },
];

const steps = [
  { icon: Phone, t: "Call or enquire", d: "Tell us the products and quantities you need." },
  { icon: BadgeCheck, t: "Get your quote", d: "Receive clear bulk pricing the same day." },
  { icon: Factory, t: "Fresh production", d: "Packed fresh at our Saptari facility." },
  { icon: Truck, t: "Delivered", d: "Dispatched on time to your shop or warehouse." },
];

function Index() {
  return (
    <>
      <section className="relative overflow-hidden bg-deep">
        <img src={hero} alt="Chiura and bhuja in bamboo baskets" width={1600} height={1008} className="absolute inset-0 h-full w-full object-cover opacity-60" />
        <div className="absolute inset-0 bg-hero-overlay" />
        <div className="relative mx-auto grid max-w-6xl items-center gap-10 px-6 py-20 text-deep-foreground md:py-28">
          <div className="animate-rise">
            <p className="inline-flex items-center gap-2 rounded-full border border-gold/40 bg-deep/40 px-4 py-1.5 text-sm font-semibold text-gold">
              <ShieldCheck className="h-4 w-4" /> Proudly Nepali · {company.nameNe}
            </p>
            <h1 className="mt-6 max-w-2xl text-5xl font-semibold leading-[1.04] md:text-7xl">
              Quality Grains.
              <br />
              <span className="italic text-gold">Built on Trust.</span>
            </h1>
            <p className="mt-6 max-w-lg text-lg opacity-90">
              Premium chiura and bhuja for wholesalers, retailers and distributors in every corner of Nepal — made fresh in Saptari.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Link to="/contact" className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3.5 font-semibold text-primary-foreground shadow-lift transition hover:brightness-110">
                Get bulk pricing <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/products" className="inline-flex items-center rounded-full border border-deep-foreground/40 px-7 py-3.5 font-semibold transition hover:bg-deep-foreground/10">
                View products
              </Link>
            </div>
          </div>
        </div>
        <div className="relative border-t border-deep-foreground/15 bg-deep/70 backdrop-blur">
          <div className="mx-auto grid max-w-6xl grid-cols-2 gap-6 px-6 py-7 text-deep-foreground md:grid-cols-4">
            {stats.map((s) => (
              <div key={s.l}>
                <p className="font-display text-3xl text-gold">{s.n}</p>
                <p className="text-sm opacity-75">{s.l}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section aria-label="All products" className="overflow-hidden border-b border-border bg-secondary/60 py-8">
        <div className="flex w-max animate-marquee-right gap-6 hover:[animation-play-state:paused]">
          {[...products, ...products].map((p, i) => (
            <Link key={i} to="/products" className="group flex w-72 shrink-0 items-center gap-4 rounded-2xl border border-border bg-card p-4 shadow-soft transition hover:-translate-y-1 hover:shadow-lift">
              <span className="grid h-24 w-24 shrink-0 place-items-center overflow-hidden rounded-xl border border-border bg-card">
                <ProductImage src={p.image} fallback={categoryImage[p.category]} alt={`${p.name} ${p.size}`} className="transition-transform duration-500 group-hover:scale-110" />
              </span>
              <span className="leading-tight">
                <span className="block font-semibold">{p.name}</span>
                <span className="mt-1 block text-xs text-muted-foreground">{p.nameNe}</span>
                <span className="mt-2 inline-block rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-bold text-primary">{p.size}</span>
              </span>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-24">
        <p className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">Why businesses choose us</p>
        <h2 className="mt-3 max-w-2xl text-3xl font-semibold md:text-5xl">A supplier you can build your business on.</h2>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f) => (
            <div key={f.title} className="group rounded-2xl border border-border bg-card p-7 transition hover:-translate-y-1 hover:shadow-lift">
              <span className="grid h-12 w-12 place-items-center rounded-xl bg-primary/10 text-primary transition group-hover:bg-primary group-hover:text-primary-foreground">
                <f.icon className="h-6 w-6" />
              </span>
              <h3 className="mt-5 text-xl font-semibold">{f.title}</h3>
              <p className="mt-2 text-muted-foreground">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6">
        <h2 className="text-3xl font-semibold md:text-4xl">Two products, done right.</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-2">
          {[
            { img: bhuja, title: "Bhuja / Muri", ne: "मख्खन भुजा", text: "Light, airy puffed rice — 3, 5, 10 and 13 kg packs." },
            { img: chiura, title: "Chiura", ne: "चिउरा", text: "Crisp Kurum Kurum flattened rice — 400 g to 20 kg." },
          ].map((c) => (
            <Link key={c.title} to="/products" className="group relative overflow-hidden rounded-3xl shadow-lift">
              <img src={c.img} alt={c.title} loading="lazy" width={1024} height={1024} className="aspect-[16/11] w-full object-cover transition-transform duration-700 group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-t from-deep/90 via-deep/20 to-transparent" />
              <div className="absolute bottom-0 p-7 text-deep-foreground">
                <p className="text-sm opacity-80">{c.ne}</p>
                <h3 className="text-3xl font-semibold">{c.title}</h3>
                <p className="mt-1 opacity-90">{c.text}</p>
                <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-gold">Explore <ArrowRight className="h-4 w-4" /></span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 pt-24">
        <div className="flex items-end justify-between gap-4">
          <h2 className="text-3xl font-semibold md:text-4xl">Popular packs</h2>
          <Link to="/products" className="flex items-center gap-1 font-semibold text-primary">
            View all <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {[1, 5, 6].map((i) => products[i]!).map((p) => (
            <ProductCard key={p.nameNe} p={p} />
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 pt-24">
        <p className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">How ordering works</p>
        <h2 className="mt-3 text-3xl font-semibold md:text-4xl">From enquiry to delivery in four steps.</h2>
        <ol className="mt-10 grid gap-6 md:grid-cols-4">
          {steps.map((s, i) => (
            <li key={s.t} className="relative rounded-2xl border border-border bg-card p-6">
              <span className="font-display text-5xl text-gold">0{i + 1}</span>
              <s.icon className="absolute right-6 top-7 h-6 w-6 text-primary" />
              <h3 className="mt-3 text-lg font-semibold">{s.t}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{s.d}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="mx-auto max-w-6xl px-6 pt-24">
        <div className="relative overflow-hidden rounded-3xl bg-deep px-8 py-14 text-deep-foreground shadow-lift md:px-14">
          <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-crimson/40 blur-3xl" />
          <div className="relative flex flex-col items-start justify-between gap-8 md:flex-row md:items-center">
            <div>
              <h2 className="text-3xl font-semibold md:text-4xl">Become a TSKU distributor.</h2>
              <p className="mt-3 max-w-lg opacity-85">Call {company.phones[1]} or send an enquiry for wholesale rates and partnership terms.</p>
            </div>
            <div className="flex flex-wrap gap-3">
              <a href={`tel:${company.phones[1]}`} className="inline-flex items-center gap-2 rounded-full bg-gold px-6 py-3 font-semibold text-accent-foreground">
                <Phone className="h-4 w-4" /> Call now
              </a>
              <Link to="/contact" className="rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground">
                Send enquiry
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
