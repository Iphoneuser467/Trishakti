import b3 from "@/assets/makkhan-bhuja-3kg.webp.asset.json";
import b5 from "@/assets/makkhan-bhuja-5kg-corrected.webp.asset.json";
import b10 from "@/assets/makkhan-bhuja-10kg.webp.asset.json";
import b13 from "@/assets/makkhan-bhuja-13kg.webp.asset.json";
import k400 from "@/assets/kurum-kurum-400g.webp.asset.json";
import k800 from "@/assets/kurum-kurum-800g.webp.asset.json";
import k20 from "@/assets/kurum-kurum-20kg.webp.asset.json";
import t5 from "@/assets/trishakti-chiura-5kg.webp.asset.json";
import t20 from "@/assets/trishakti-chiura-20kg.webp.asset.json";
import chiura from "@/assets/chiura.jpg";
import bhuja from "@/assets/bhuja.jpg";

export const company = {
  name: "Trishakti Khadhya Udhyog",
  nameNe: "त्रिशक्ति खाद्य उद्योग",
  short: "TSKU",
  email: "prakashnayak467@gmail.com",
  phones: ["031-440053", "9842910781", "9819707949"],
  address: "Hanumannagar-Kankalini, Ward 03, Saptari, Nepal",
};

export type Category = "Bhuja / Muri" | "Chiura";

export const categoryImage: Record<Category, string> = {
  "Bhuja / Muri": bhuja,
  Chiura: chiura,
};

export const products: { name: string; nameNe: string; size: string; category: Category; image: string }[] = [
  { name: "Makhhan Bhuja", nameNe: "मख्खन भुजा ३ के.जी.", size: "3 kg", category: "Bhuja / Muri", image: b3.url },
  { name: "Makhhan Bhuja", nameNe: "मख्खन भुजा ५ के.जी.", size: "5 kg", category: "Bhuja / Muri", image: b5.url },
  { name: "Makhhan Bhuja", nameNe: "मख्खन भुजा १० के.जी.", size: "10 kg", category: "Bhuja / Muri", image: b10.url },
  { name: "Makhhan Bhuja", nameNe: "मख्खन भुजा १३ के.जी.", size: "13 kg", category: "Bhuja / Muri", image: b13.url },
  { name: "Makhhan Kurum Kurum Chiura", nameNe: "मख्खन चिउरा कुरुम कुरुम ४०० ग्राम", size: "400 g", category: "Chiura", image: k400.url },
  { name: "Makhhan Kurum Kurum Chiura", nameNe: "मख्खन चिउरा कुरुम कुरुम ८०० ग्राम", size: "800 g", category: "Chiura", image: k800.url },
  { name: "Trishakti Chiura", nameNe: "त्रिशक्ति चिउरा ५ के.जी.", size: "5 kg", category: "Chiura", image: t5.url },
  { name: "Makhhan Kurum Kurum Chiura", nameNe: "मख्खन चिउरा कुरुम कुरुम २० के.जी.", size: "20 kg", category: "Chiura", image: k20.url },
  { name: "Trishakti Chiura", nameNe: "त्रिशक्ति चिउरा २० के.जी.", size: "20 kg", category: "Chiura", image: t20.url },
];
